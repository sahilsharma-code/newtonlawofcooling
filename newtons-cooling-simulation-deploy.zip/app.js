// Newton's Law of Cooling - Interactive Logic Engine

// Global State
let currentScenario = 'csi';
let simulationTime = 0; // current time in simulation (minutes or hours)
let playbackInterval = null;
let isPlaying = false;
let chartInstance = null;

// Scenario Configurations
const scenarios = {
  csi: {
    name: 'CSI: Forensic Investigator',
    timeUnit: 'hours',
    timeLabel: 'Hours Elapsed',
    maxTime: 12,
    params: {
      t0: { label: 'Body Temp when Found (°C)', min: 22, max: 36, val: 29.5, step: 0.1 },
      tm: { label: 'Ambient Room Temp (°C)', min: 10, max: 25, val: 18.0, step: 0.5 },
      k: { label: 'Cooling Constant (k/hr)', min: 0.05, max: 0.40, val: 0.15, step: 0.01 }
    },
    // CSI special math uses T_body = 37°C at t = 0 (Time of Death)
    // T_found is the temperature at elapsed time t_elapsed
    calculate: (t, p) => {
      // Newton's cooling formula: T(t) = Tm + (T_normal - Tm) * e^(-k * t)
      // Since death happens at t = 0 (Body at 37°C), body cools down towards Tm.
      const normalBodyTemp = 37.0; 
      return p.tm + (normalBodyTemp - p.tm) * Math.exp(-p.k * t);
    }
  },
  brew: {
    name: 'The Perfect Coffee Brew',
    timeUnit: 'mins',
    timeLabel: 'Time Elapsed',
    maxTime: 60,
    params: {
      t0: { label: 'Initial Brew Temp (°C)', min: 70, max: 95, val: 85.0, step: 1.0 },
      tm: { label: 'Room Temperature (°C)', min: 15, max: 35, val: 22.0, step: 0.5 },
      k: { label: 'Cup Heat Loss Rate (k/min)', min: 0.01, max: 0.08, val: 0.035, step: 0.001 }
    },
    calculate: (t, p) => {
      // T(t) = Tm + (T0 - Tm) * e^(-k * t)
      return p.tm + (p.t0 - p.tm) * Math.exp(-p.k * t);
    }
  },
  cast: {
    name: 'Industrial Metal Quenching',
    timeUnit: 'seconds',
    timeLabel: 'Time Elapsed',
    maxTime: 180,
    params: {
      t0: { label: 'Forging Metal Temp (°C)', min: 500, max: 1000, val: 800, step: 10 },
      tm: { label: 'Quench Bath Temp (°C)', min: 10, max: 80, val: 30, step: 1 },
      k: { label: 'Convection Coefficient (k/sec)', min: 0.01, max: 0.15, val: 0.04, step: 0.005 }
    },
    calculate: (t, p) => {
      return p.tm + (p.t0 - p.tm) * Math.exp(-p.k * t);
    }
  }
};

// UI Elements
const scenarioButtons = document.querySelectorAll('.scenario-btn');
const controlPanel = document.getElementById('scenario-controls');
const tabButtons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');
const playBtn = document.getElementById('play-btn');
const timelineSlider = document.getElementById('timeline');
const timelineCurrentTime = document.getElementById('time-current');
const timelineMaxTime = document.getElementById('time-max');
const coolingObject = document.getElementById('cooling-obj');
const objectTempDisplay = document.getElementById('obj-temp');
const particleContainer = document.getElementById('particle-container');

// Stats Displays
const stat1Value = document.getElementById('stat-1-val');
const stat2Value = document.getElementById('stat-2-val');
const stat3Value = document.getElementById('stat-3-val');
const stat1Label = document.getElementById('stat-1-lbl');
const stat2Label = document.getElementById('stat-2-lbl');
const stat3Label = document.getElementById('stat-3-lbl');

// Modal Elements
const deployBtn = document.getElementById('deploy-btn');
const modalOverlay = document.getElementById('modal-overlay');
const modalClose = document.getElementById('modal-close');

// Initial setup
document.addEventListener('DOMContentLoaded', () => {
  setupScenario(currentScenario);
  setupEventListeners();
  updateSimulation();
});

// Setup input controls for the chosen scenario
function setupScenario(scenarioKey) {
  currentScenario = scenarioKey;
  const config = scenarios[scenarioKey];
  
  // Update timeline slider maximums
  timelineSlider.max = config.maxTime;
  timelineSlider.value = 0;
  simulationTime = 0;
  timelineCurrentTime.textContent = `0 ${config.timeUnit}`;
  timelineMaxTime.textContent = `${config.maxTime} ${config.timeUnit}`;
  
  // Pause simulation if active
  pauseSimulation();

  // Re-build controls dynamically based on scenario parameters
  controlPanel.innerHTML = '';
  Object.keys(config.params).forEach(key => {
    const param = config.params[key];
    const group = document.createElement('div');
    group.className = 'control-group';
    
    group.innerHTML = `
      <div class="control-label">
        <span>${param.label}</span>
        <span class="control-value" id="val-${key}">${param.val}</span>
      </div>
      <input type="range" class="range-slider" id="input-${key}" 
             min="${param.min}" max="${param.max}" step="${param.step}" value="${param.val}">
    `;
    
    controlPanel.appendChild(group);

    // Attach input event listeners
    const slider = group.querySelector('input');
    slider.addEventListener('input', (e) => {
      param.val = parseFloat(e.target.value);
      document.getElementById(`val-${key}`).textContent = param.val;
      updateSimulation();
    });
  });

  // Adjust Visualizer Object Shape Class
  coolingObject.className = 'cooling-object';
  if (scenarioKey === 'csi') {
    coolingObject.classList.add('human-body');
  } else if (scenarioKey === 'brew') {
    coolingObject.classList.add('coffee-cup');
  } else if (scenarioKey === 'cast') {
    coolingObject.classList.add('metal-gear');
  }

  // Draw or redraw Chart.js canvas
  initChart();
}

// Gather currently set parameters from scenario
function getParams() {
  const config = scenarios[currentScenario];
  const params = {};
  Object.keys(config.params).forEach(key => {
    params[key] = config.params[key].val;
  });
  return params;
}

// Generate coordinate points for Chart.js
function generateChartData(config, params) {
  const data = [];
  const step = config.maxTime / 100;
  for (let t = 0; t <= config.maxTime; t += step) {
    data.push({ x: parseFloat(t.toFixed(2)), y: parseFloat(config.calculate(t, params).toFixed(2)) });
  }
  // Ensure the final point matches maxTime exactly
  data.push({ x: config.maxTime, y: parseFloat(config.calculate(config.maxTime, params).toFixed(2)) });
  return data;
}

// Initialize/Re-create chart
function initChart() {
  const ctx = document.getElementById('cooling-chart').getContext('2d');
  const config = scenarios[currentScenario];
  const params = getParams();
  const points = generateChartData(config, params);

  // If a chart already exists, destroy it first
  if (chartInstance) {
    chartInstance.destroy();
  }

  // Create chart instance
  chartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      datasets: [
        {
          label: 'Temperature (°C)',
          data: points,
          borderColor: '#6366f1',
          borderWidth: 3,
          backgroundColor: 'rgba(99, 102, 241, 0.1)',
          fill: true,
          tension: 0.3,
          pointRadius: 0,
          pointHoverRadius: 6,
        },
        {
          label: 'Ambient Temp',
          data: [
            { x: 0, y: params.tm },
            { x: config.maxTime, y: params.tm }
          ],
          borderColor: 'rgba(6, 182, 212, 0.6)',
          borderWidth: 2,
          borderDash: [5, 5],
          pointRadius: 0,
          fill: false
        },
        // Dedicated point dataset to track current playback time
        {
          label: 'Current State',
          data: [{ x: 0, y: points[0].y }],
          borderColor: '#f43f5e',
          backgroundColor: '#f43f5e',
          pointRadius: 6,
          pointHoverRadius: 8,
          fill: false,
          showLine: false
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          type: 'linear',
          title: {
            display: true,
            text: config.timeLabel + ` (${config.timeUnit})`,
            color: '#94a3b8',
            font: { family: 'Plus Jakarta Sans', weight: 600 }
          },
          ticks: { color: '#64748b' },
          grid: { color: 'rgba(255, 255, 255, 0.04)' }
        },
        y: {
          title: {
            display: true,
            text: 'Temperature (°C)',
            color: '#94a3b8',
            font: { family: 'Plus Jakarta Sans', weight: 600 }
          },
          ticks: { color: '#64748b' },
          grid: { color: 'rgba(255, 255, 255, 0.04)' }
        }
      },
      plugins: {
        legend: {
          labels: {
            color: '#f8fafc',
            font: { family: 'Plus Jakarta Sans' }
          }
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      }
    }
  });
}

// Update simulation visuals, outputs, and chart highlights
function updateSimulation() {
  const config = scenarios[currentScenario];
  const params = getParams();
  
  // Calculate current temperature
  const currentTemp = config.calculate(simulationTime, params);
  
  // 1. Update the temperature indicator inside the vessel
  objectTempDisplay.textContent = `${currentTemp.toFixed(1)}°C`;
  
  // 2. Interpolate background color for object based on hot/cool temperatures
  // Determine normalized heat ratio based on scenario limit variables
  let minLimit = params.tm;
  let maxLimit = currentScenario === 'csi' ? 37.0 : params.t0;
  let ratio = Math.max(0, Math.min(1, (currentTemp - minLimit) / (maxLimit - minLimit || 1)));
  
  // Color mapping: interpolate HSL between Cyan (180 deg) and Orange/Red (15 deg)
  const hue = 180 - (ratio * 165); // 180 (cold cyan) to 15 (hot red-orange)
  const lightness = 40 + (ratio * 15); // 40% to 55%
  
  coolingObject.style.backgroundColor = `hsl(${hue}, 85%, ${lightness}%)`;
  coolingObject.style.boxShadow = `0 0 ${20 + (ratio * 30)}px hsl(${hue}, 85%, 50%)`;
  
  // Update particles frequency based on temperature
  updateParticles(ratio);

  // 3. Update Chart current point tracking
  if (chartInstance) {
    // Dynamic Ambient line update
    chartInstance.data.datasets[1].data = [
      { x: 0, y: params.tm },
      { x: config.maxTime, y: params.tm }
    ];
    
    // Core curve recalculation
    const points = generateChartData(config, params);
    chartInstance.data.datasets[0].data = points;

    // Current State tracker marker reposition
    chartInstance.data.datasets[2].data = [{ x: simulationTime, y: currentTemp }];
    
    chartInstance.update('none'); // silent update without reset transitions
  }

  // 4. Update Scenario-Specific HUD Statistics
  updateHUD(currentTemp, params, config);
}

// Populate Scenario HUD values
function updateHUD(currentTemp, params, config) {
  if (currentScenario === 'csi') {
    stat1Label.textContent = 'Time Since Death';
    // CSI math solves for: t = (1/k) * ln((T_normal - Tm) / (T_found - Tm))
    // Note: here, T_found is target parameter val (t0) and T_normal = 37°C
    const normal = 37.0;
    
    let hoursElapsed = 0;
    if (params.t0 > params.tm) {
      hoursElapsed = (1 / params.k) * Math.log((normal - params.tm) / (params.t0 - params.tm));
    }
    
    stat1Value.textContent = hoursElapsed > 0 ? `${hoursElapsed.toFixed(2)} hrs` : 'N/A';
    stat1Value.className = 'stat-value highlight-red';

    stat2Label.textContent = 'Current Simulation Temp';
    stat2Value.textContent = `${currentTemp.toFixed(1)}°C`;
    stat2Value.className = 'stat-value';

    stat3Label.textContent = 'Victim Discovery Temp';
    stat3Value.textContent = `${params.t0.toFixed(1)}°C`;
    stat3Value.className = 'stat-value';
    
  } else if (currentScenario === 'brew') {
    stat1Label.textContent = 'Brew Status';
    // perfect drink range is between 58°C and 65°C
    if (currentTemp > 65) {
      stat1Value.textContent = 'Too Hot ☕';
      stat1Value.className = 'stat-value highlight-red';
    } else if (currentTemp >= 58) {
      stat1Value.textContent = 'Perfect Sip! 😍';
      stat1Value.className = 'stat-value highlight-green';
    } else {
      stat1Value.textContent = 'Too Cold ❄️';
      stat1Value.className = 'stat-value';
    }

    stat2Label.textContent = 'Time to Perfect Sip';
    // Solve for t when Temp = 62.5°C (midpoint of perfect range)
    const targetPerfect = 61.5;
    let perfectTime = 0;
    if (params.t0 > targetPerfect && targetPerfect > params.tm) {
      perfectTime = (1 / params.k) * Math.log((params.t0 - params.tm) / (targetPerfect - params.tm));
      stat2Value.textContent = `${Math.ceil(perfectTime)} mins`;
    } else if (params.t0 <= targetPerfect) {
      stat2Value.textContent = 'Passed';
    } else {
      stat2Value.textContent = 'Never (Room too cold)';
    }
    stat2Value.className = 'stat-value';

    stat3Label.textContent = 'Ambient Heat Diff';
    stat3Value.textContent = `${Math.max(0, currentTemp - params.tm).toFixed(1)}°C`;
    stat3Value.className = 'stat-value';
    
  } else if (currentScenario === 'cast') {
    stat1Label.textContent = 'Casting State';
    // Metal solidifies at high temperatures, we monitor cooling safety
    if (currentTemp > 500) {
      stat1Value.textContent = 'Glowing Incandescent 🔴';
      stat1Value.className = 'stat-value highlight-red';
    } else if (currentTemp > 150) {
      stat1Value.textContent = 'Dangerously Hot ⚠️';
      stat1Value.className = 'stat-value highlight-red';
    } else if (currentTemp > 50) {
      stat1Value.textContent = 'Cooled (Warm)';
      stat1Value.className = 'stat-value';
    } else {
      stat1Value.textContent = 'Safe to Handle ✅';
      stat1Value.className = 'stat-value highlight-green';
    }

    stat2Label.textContent = 'Quench Rate (dT/dt)';
    // Rate of change = -k * (T - Tm)
    const rate = -params.k * (currentTemp - params.tm);
    stat2Value.textContent = `${rate.toFixed(1)}°C/s`;
    stat2Value.className = 'stat-value';

    stat3Label.textContent = 'Initial Thermal Shock';
    stat3Value.textContent = `${(params.t0 - params.tm).toFixed(0)}°C Δ`;
    stat3Value.className = 'stat-value';
  }
}

// Generate animated floating steam/heat particles inside visualizer screen
function updateParticles(ratio) {
  // Clear extra particles
  const currentParticles = particleContainer.querySelectorAll('.particle');
  const targetCount = Math.floor(ratio * 12); // Hotter = more steam
  
  if (currentParticles.length < targetCount) {
    for (let i = currentParticles.length; i < targetCount; i++) {
      const p = document.createElement('div');
      p.className = 'particle';
      p.style.left = `${Math.random() * 80 + 10}%`;
      p.style.setProperty('--x-offset', `${Math.random() * 40 - 20}px`);
      p.style.animationDelay = `${Math.random() * 4}s`;
      p.style.animationDuration = `${3 + Math.random() * 2}s`;
      particleContainer.appendChild(p);
    }
  } else if (currentParticles.length > targetCount) {
    for (let i = 0; i < currentParticles.length - targetCount; i++) {
      currentParticles[i].remove();
    }
  }
}

// Simulation Playback Controls
function playSimulation() {
  if (isPlaying) return;
  isPlaying = true;
  playBtn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>`; // Pause Icon
  
  const config = scenarios[currentScenario];
  const stepSize = config.maxTime / 120; // 120 ticks total for the simulation duration
  const tickSpeed = 50; // ms per tick

  playbackInterval = setInterval(() => {
    simulationTime += stepSize;
    if (simulationTime >= config.maxTime) {
      simulationTime = config.maxTime;
      pauseSimulation();
    }
    timelineSlider.value = simulationTime;
    timelineCurrentTime.textContent = `${simulationTime.toFixed(1)} ${config.timeUnit}`;
    updateSimulation();
  }, tickSpeed);
}

function pauseSimulation() {
  if (!isPlaying) return;
  isPlaying = false;
  clearInterval(playbackInterval);
  playBtn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>`; // Play Icon
}

// Handle all event listeners
function setupEventListeners() {
  // Scenario Selection buttons
  scenarioButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      scenarioButtons.forEach(b => b.classList.remove('active'));
      const activeBtn = e.target.closest('.scenario-btn');
      activeBtn.classList.add('active');
      setupScenario(activeBtn.dataset.scenario);
      updateSimulation();
    });
  });

  // Play/Pause Button
  playBtn.addEventListener('click', () => {
    if (isPlaying) {
      pauseSimulation();
    } else {
      // Loop reset if clicking play at final tick
      const config = scenarios[currentScenario];
      if (simulationTime >= config.maxTime) {
        simulationTime = 0;
        timelineSlider.value = 0;
      }
      playSimulation();
    }
  });

  // Timeline Slider scrub
  timelineSlider.addEventListener('input', (e) => {
    pauseSimulation();
    simulationTime = parseFloat(e.target.value);
    const config = scenarios[currentScenario];
    timelineCurrentTime.textContent = `${simulationTime.toFixed(1)} ${config.timeUnit}`;
    updateSimulation();
  });

  // Math Lab vs Visualization Tab Switch
  tabButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      tabButtons.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      
      e.target.classList.add('active');
      const targetId = e.target.dataset.tab;
      document.getElementById(targetId).classList.add('active');
    });
  });

  // Modal Open/Close Event Listeners for Hosting/Deployment
  deployBtn.addEventListener('click', () => {
    modalOverlay.classList.add('active');
  });

  modalClose.addEventListener('click', () => {
    modalOverlay.classList.remove('active');
  });

  modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) {
      modalOverlay.classList.remove('active');
    }
  });
}
